#This is based on the CS50 beyond course

x = int(input("Enter a value for x:"))

if x > 0:
    print("x is positive")
elif x == 0:
    print("x is zero")
else:
    print("x is negative")

