# home

Hello! This is my first repository. No idea where this will go but super excited to write some code!

Thanks for stopping by.
