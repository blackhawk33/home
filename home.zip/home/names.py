name = "Geoff"
names = ["Cam","JT","Mimi"]

s = int(input("Which family member are you looking for? (1-3):"))

print (names[s-1])
